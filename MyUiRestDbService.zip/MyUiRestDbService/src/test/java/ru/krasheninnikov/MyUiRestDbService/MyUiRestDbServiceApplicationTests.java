package ru.krasheninnikov.MyUiRestDbService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyUiRestDbServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
