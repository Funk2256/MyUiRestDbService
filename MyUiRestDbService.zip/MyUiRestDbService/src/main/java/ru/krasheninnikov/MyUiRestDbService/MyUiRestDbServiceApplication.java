package ru.krasheninnikov.MyUiRestDbService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyUiRestDbServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyUiRestDbServiceApplication.class, args);
	}

}
